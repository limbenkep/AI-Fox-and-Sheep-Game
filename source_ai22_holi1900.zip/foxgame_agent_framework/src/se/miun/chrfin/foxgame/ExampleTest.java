package se.miun.chrfin.foxgame;

import net.finkn.foxgame.PerformanceTest;
import net.finkn.foxgame.adapters.EngineFactory;
import se.miun.chrfin.foxgame.setup.PlayerSetup;

import static net.finkn.foxgame.util.Role.FOX;
import static net.finkn.foxgame.util.Role.SHEEP;

public class ExampleTest {
  public static void main(String[] args) {
    EngineFactory factory = new MyFactory();
    boolean result;

    // Some example tests...

    // Use the default test parameters.
    //result = PerformanceTest.test(factory).run();
    //System.out.println("Result: " + result);

    // Tweaking each parameter.
    result = PerformanceTest.test(factory)
      .seeds(122, 244) // Use random() for a random seed (default is 1)
      .matches(5)       // Run 5 matches per level (default is 10)
      .levels(1)     // Runs levels 0 and 2 (default is 0, 1, and 2) (max 3)
      .timeouts(200)    // Use 200 ms timeout (default is 500 and 300)
      .roles(SHEEP)       // Only play as fox (default is FOX and SHEEP)
      .agents(new MyFactory()) // Want to play against another agent? Put it
                        // here. Not used by default.
      .run(.5);         // Win threshold of 50% (default is 80%)
    System.out.println("Result: " + result);

  }
}

class MyFactory implements EngineFactory {
  @Override
  public AiGameEngine getEngine(String role) {
    //String ipAddress, int gamePort, String playerRole,
    //			String playerName, String fileName
    return new FoxGameEngine(new PlayerSetup("localhost", 6000, role, "Honorine", "~/Programming/dt175g_project/foxgame_agent_framework"));
    //return null; // Your code here.
    // Something like
    // return new AwesomeFoxgameEngine();
  }

  @Override
  public String toString() {
    return "Honorine"; // Or "AwesomeFoxgameEngine" if you want to. :)
  }
}
