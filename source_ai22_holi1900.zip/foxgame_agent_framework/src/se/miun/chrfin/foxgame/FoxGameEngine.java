package se.miun.chrfin.foxgame;

import ch.rfin.foxgame.Foxgame;
import ch.rfin.foxgame.Pos;
import ch.rfin.foxgame.Role;
import ch.rfin.foxgame.rules.Board;
import ch.rfin.foxgame.rules.State;
import ch.rfin.foxgame.util.Util;
import se.miun.chrfin.foxgame.com.GameStatus;
import se.miun.chrfin.foxgame.setup.PlayerSetup;

import java.util.*;

/**
 * @author Lima Honorine
 */
public class FoxGameEngine implements AiGameEngine {

  private final PlayerSetup setup;
  private final Foxgame foxgame = Foxgame.instance;
  private State state = foxgame.getRoot(); //current state of the game initialized as the root state
  private Node currentNode = new Node(state, null, null); //current node
  private final Role maxPlayer= Role.FOX;
  private final Role minPlayer = Role.SHEEP;
  private final List<Board> history = new ArrayList<>();
  double timeSlice = 0;//time allocated to prepare and make a move
  private long startTime = 0; // start of allocating time
  private long endTime = 0; // end of allocating time


  public FoxGameEngine(PlayerSetup setup) {
    this.setup = setup;
  }

  /**
   * Return a move of the form "x1,y1 x2,y2".
   */
  @Override
  public String getMove(GameStatus status) {
    startTime = System.currentTimeMillis();
    timeSlice = status.timeSlice - 40;
    endTime = startTime + (long)(timeSlice);
    long startTime = System.currentTimeMillis();
    double halfTime = status.timeSlice*0.5;
    if(!status.isGameOver()){
      String player = status.playerRole;
      if(Objects.equals(player, maxPlayer.toString())){
        return miniMax(currentNode, 2, true, startTime, halfTime).values().iterator().next();
        //return minimaxWithPruning(currentNode, 5,Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, true, startTime, halfTime).values().iterator().next();
      } else if (Objects.equals(player, minPlayer.toString())) {
        return miniMax(currentNode, 2, false, startTime, halfTime).values().iterator().next();
        //return minimaxWithPruning(currentNode, 5,Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, false, startTime, halfTime).values().iterator().next();
      }else {
        System.out.println("Neither max nor min player");
      }
    }
    return null;
  }

  /**
   * Keeps tract of the changes in the game state when moves are made.
   * Get the resulting state when a move is made and updates the current node with that state.
   * @param move the move made
   */
  @Override
  public void updateState(String move) {
    if(move == null){
      state = foxgame.getRoot();
    }else{
      State newState = foxgame.transition(state, move);
      Node parent = currentNode;
      currentNode = new Node(newState, move, parent);
      history.add(state.getBoard());
      state = newState;
    }
  }

  @Override
  public String getPlayerName() {
    return setup.playerName;
  }

  public Map<Double, String> miniMax(Node p, int depth, boolean isMax, long startTime, double timeSlice) {

    if(foxgame.terminal(p.getState()) || depth==0 ||(System.currentTimeMillis()-startTime) >timeSlice){
      return Collections.singletonMap(evaluate(p.getState()), p.getMove());
    }
    Collection<Node> children =generateChildNodes(p);
    if(children.isEmpty()){
      return Collections.singletonMap(0.0, p.getMove());
    }
    double bestScore;
    String  bestMove;
    if(isMax){
      bestScore  = Double.NEGATIVE_INFINITY;
      bestMove = null;
      for(Node child: children){
        Map<Double, String> result = miniMax(child, depth-1, false, startTime, timeSlice);
        double score = result.keySet().iterator().next();
        if(score>bestScore){
          bestScore = score;
          bestMove = child.getMove();
        }
      }
      return Collections.singletonMap(bestScore, bestMove);
    }else {
      bestScore = Double.POSITIVE_INFINITY;
      bestMove = null;
      for(Node child: children){
        Map<Double, String> result = miniMax(child, depth-1, true, startTime, timeSlice);
        double score = result.keySet().iterator().next();
        if(score<bestScore){
          bestScore=score;
          bestMove = child.getMove();
        }
      }
      return Collections.singletonMap(bestScore, bestMove);
    }
  }

  private Map<Double, String> iterativeDeepeningSearch(Node p,boolean isMax) {

    int depth = 1;
    Map<Double, String> score = null;
    boolean searchCutoff = false;

    while (true) {
      long currentTime = System.currentTimeMillis();

      if (currentTime >= endTime) {
        break;
      }

      Map<Double, String> searchResult = minimaxWithPruning(p, depth, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, isMax, startTime, timeSlice);
      if (!searchCutoff) {
        score = searchResult;
      }
      depth++;
    }
    return score;
  }
  public Map<Double, String> minimaxWithPruning(Node p, int depth, double alpha, double beta, boolean isMax, long startTime, double timeSlice) {

    if(foxgame.terminal(p.getState()) || depth==0 ||System.currentTimeMillis()-startTime <timeSlice){
      return Collections.singletonMap(evaluate(p.getState()), p.getMove());
    }
    Collection<Node> children =generateChildNodes(p);
    if(children.isEmpty()){
      return Collections.singletonMap(0.0, p.getMove());
    }
    double bestScore;
    String  bestMove;
    if(isMax){
      Comparator<Node> nodeComparator = (a,b) -> Double.compare(0-evaluate(a.getState()), 0-evaluate(b.getState()));
      PriorityQueue<Node> orderedChildren = new PriorityQueue<>(10, nodeComparator);
      orderedChildren.addAll(children);
      bestScore  = Double.NEGATIVE_INFINITY;
      bestMove = null;
      for(Node child: orderedChildren){
        Map<Double, String> result = minimaxWithPruning(child, depth-1,alpha, beta, false, startTime, timeSlice);
        double score = result.keySet().iterator().next();
        if(score>bestScore){
          bestScore = score;
          bestMove = child.getMove();
          alpha = Math.max(alpha, bestScore);
        }
        if(score>=beta){
          return Collections.singletonMap(bestScore, bestMove);
        }
      }
      return Collections.singletonMap(bestScore, bestMove);
    }else {
      Comparator<Node> nodeComparator = (a,b) -> Double.compare(evaluate(a.getState()), evaluate(b.getState()));
      PriorityQueue<Node> orderedChildren = new PriorityQueue<>(10, nodeComparator);
      orderedChildren.addAll(children);
      bestScore = Double.POSITIVE_INFINITY;
      bestMove = null;
      for(Node child: orderedChildren){
        Map<Double, String> result = minimaxWithPruning(child, depth-1,alpha, beta, true, startTime, timeSlice);
        double score = result.keySet().iterator().next();

        if(score<bestScore){
          bestScore=score;
          bestMove = child.getMove();
          beta = Math.min(beta, bestScore);
        }
        if(score<=alpha){
          return Collections.singletonMap(bestScore, bestMove);
        }
      }
      return Collections.singletonMap(bestScore, bestMove);
    }
  }

  /**
   * Generates the childNodes for the passed node and check if the board configuration is
   * @param p nodes to generate child from
   * @return a list of child nodes whose board configurations have not occured before during the game
   */
  private Collection<Node> generateChildNodes(Node p) {
    List<Node> children = new ArrayList<>();
    Collection<String> possibleMoves = foxgame.possibleActionsIn(p.getState());
    for(String move: possibleMoves){
      State child = foxgame.transition(p.getState(), move);
      if(!recurringState(child)){
        children.add(new Node(child, move, p));
      }
    }
    return children;
  }

  /**
   * Evaluation function to be used for evaluating the nodes in the minimax function.
   * Calculates the number of foxes  -  number of sheep
   * @param state state to be evaluated.
   * @return the number of foxes  -  number of sheep
   */
  private double evaluate(State state){
    int totalFox = state.getFoxes().size();
    int totalSheep = state.getSheep().size();
    return (double)totalFox - totalSheep;
  }

  /**
   * Checks if a given state's board configuration has been encountered before during the game
   * @param state the state to be checked
   * @return true if the board configuration had occurred before during the game, else false
   */
  private boolean recurringState(State state){
    for(Board board : history){
      if(Util.sorted(board.getFoxes()).equals(Util.sorted(state.getFoxes())) &&
              Util.sorted(board.getSheep()).equals(Util.sorted(state.getSheep()))){
        return true;
      }
    }
    return false;
  }

}
