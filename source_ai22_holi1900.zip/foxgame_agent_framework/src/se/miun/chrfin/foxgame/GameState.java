package se.miun.chrfin.foxgame;

import ch.rfin.foxgame.Pos;
import ch.rfin.foxgame.Role;
import ch.rfin.foxgame.rules.Board;
import ch.rfin.foxgame.rules.State;
import ch.rfin.foxgame.util.Util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class GameState implements State, Cloneable {

    private final Role currentPlayer;
    private final List<Pos> foxes;
    private final List<Pos> sheep;
    private final List<Pos> empty;
    private final State parent;


    public GameState(Role currentPlayer, List<Pos> foxes, List<Pos> sheep, List<Pos> empty, State parent) {
        this.currentPlayer = currentPlayer;
        this.foxes = foxes;
        this.sheep = sheep;
        this.empty = empty;
        this.parent = parent;
    }

    @Override
    public Role getCurrentPlayer() {
        return this.currentPlayer;
    }

    @Override
    public Board getBoard() {
        return this;
    }

    @Override
    public List<Board> getHistory() {
        return (List)(this.parent == null ? new ArrayList() : Util.conj(this.parent.getHistory(), this.parent.getBoard()));
    }

    @Override
    public Role getAt(Pos pos) {
        if (this.foxes.contains(pos)) {
            return Role.FOX;
        } else {
            return this.sheep.contains(pos) ? Role.SHEEP : Role.NONE;
        }
    }

    @Override
    public Collection<Pos> getFoxes() {
        return foxes;
    }

    @Override
    public Collection<Pos> getSheep() {
        return sheep;
    }

    @Override
    public Collection<Pos> getEmpty() {
        return this.empty;
    }


}
