package se.miun.chrfin.foxgame;

import ch.rfin.foxgame.rules.State;


/**
 * @author Lima Honorine
 */
public class Node {
    private final State state;
    private final String move;
    private final Node parent;
    public Node(State state, String move, Node parent) {
        this.state = state;
        this.move = move;
        this.parent = parent;
    }
    public State getState() {
        return state;
    }

    public String getMove() {
        return move;
    }
    public Node getParent(){
        return this.parent;
    }
}
