package se.miun.chrfin.foxgame.exceptions;

public class FoxgameSetupException extends Exception {

	private static final long serialVersionUID = 1L;

}
